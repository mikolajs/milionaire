//#include <QtCore/QCoreApplication>
#include "Questions.h"

int main(int argc, char *argv[])
{
    //QCoreApplication a(argc, argv);

    Questions q;
    q.test();
    return 0; //a.exec();
}
