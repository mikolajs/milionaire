#ifndef QUIZWINDOW_H
#define QUIZWINDOW_H



















#include <string>
#include "quiz.h"
















/**
 * Namespace
 */
/**
 * Class QuizWindow
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
class QuizWindow : public Quiz {
/**
 * Public stuff
 */
public:
    /**
     * Fields
     */
    /**
     * 
     */
    /**
     * Constructors
     */
    /**
     * Empty Constructor
     */
    TestWindow ( ) { }
    /**
     * Accessor Methods
     */
    /**
     * Operations
     */
    /**
     * 
     */
    bool newTest () {
        
    }
    /**
     * 
     */
    void showNext () {
        
    }
    /**
     * 
     */
    void endTest (bool lost) {
        
    }
    /**
     * 
     */
    void fullScreen (bool yes) {
        
    }
/**
 * Protected stuff
 */
protected:
    /**
     * Fields
     */
    /**
     * 
     */
    /**
     * Constructors
     */
    /**
     * Accessor Methods
     */
    /**
     * Operations
     */
/**
 * Private stuff
 */
private:
    /**
     * Fields
     */
    /**
     * 
     */
    /**
     * Constructors
     */
    /**
     * Accessor Methods
     */
    /**
     * Operations
     */
};
#endif //QUIZWINDOW_H

