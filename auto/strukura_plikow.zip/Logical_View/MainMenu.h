#ifndef MAINMENU_H
#define MAINMENU_H

















#include <string>
#include "quizeditor.h"
#include "qstring.h"















/**
 * Namespace
 */
/**
 * Class MainMenu
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
class MainMenu : public QuizEditor {
/**
 * Public stuff
 */
public:
    /**
     * Fields
     */
    /**
     * 
     */
    /**
     * Constructors
     */
    /**
     * Empty Constructor
     */
    MainMenu ( ) { }
    /**
     * Accessor Methods
     */
    /**
     * Operations
     */
    /**
     * 
     */
    void loadFile (QString filename) {
        
    }
    /**
     * 
     */
    void saveFile (QString filename) {
        
    }
    /**
     * 
     */
    void beginNewTests () {
        
    }
/**
 * Protected stuff
 */
protected:
    /**
     * Fields
     */
    /**
     * 
     */
    /**
     * Constructors
     */
    /**
     * Accessor Methods
     */
    /**
     * Operations
     */
/**
 * Private stuff
 */
private:
    /**
     * Fields
     */
    /**
     * 
     */
    /**
     * Constructors
     */
    /**
     * Accessor Methods
     */
    /**
     * Operations
     */
};
#endif //MAINMENU_H

